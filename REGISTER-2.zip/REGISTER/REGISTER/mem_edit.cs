﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REGISTER
{
    public partial class mem_edit : Form
    {
        public mem_edit()
        {
            InitializeComponent();
        }
    }
}
